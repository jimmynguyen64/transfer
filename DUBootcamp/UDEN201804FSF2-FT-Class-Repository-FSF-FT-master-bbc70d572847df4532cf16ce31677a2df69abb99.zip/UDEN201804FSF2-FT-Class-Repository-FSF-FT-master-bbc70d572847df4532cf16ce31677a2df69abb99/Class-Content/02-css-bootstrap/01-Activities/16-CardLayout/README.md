### File

* *None*

### Instructions

* Working in pairs and using Twitter Bootstrap make a page that looks like the following image:

  ![Card-layout design](Solved/card-layout.png)

* Be sure to note the:
  * Grid Layout
  * Navbar
  * Sidebar card
  * Thumbnail
